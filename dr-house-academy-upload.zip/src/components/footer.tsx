import Link from 'next/link';

export default function Footer() {
  return (
    <footer
      className="border-t mt-auto"
      style={{
        backgroundColor: 'var(--bg-secondary)',
        borderColor: 'var(--border-color)',
      }}
    >
      {/* ECG Divider */}
      <div className="ecg-divider" />

      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-1">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <svg width="32" height="32" viewBox="0 0 100 100">
                <path d="M30 15 L85 50 L30 85 Z" fill="#00B4D8" opacity="0.9" />
                <path d="M45 35 C45 25 55 20 60 30 L60 55 C60 65 50 70 45 60" stroke="#E63946" strokeWidth="4" fill="none" />
                <circle cx="45" cy="35" r="5" fill="#E63946" />
                <circle cx="60" cy="55" r="4" fill="#E63946" />
                <polyline points="35,50 42,50 45,40 48,58 51,45 54,50 65,50" stroke="#E63946" strokeWidth="2" fill="none" />
              </svg>
              <span className="text-lg font-bold">
                <span style={{ color: '#E63946' }}>Dr</span>{' '}
                <span style={{ color: 'var(--text-primary)' }}>House</span>
              </span>
            </Link>
            <p className="text-sm mb-4" style={{ color: 'var(--text-secondary)' }}>
              Formation médicale de haute qualité, conçue par des experts pour accompagner votre parcours professionnel.
            </p>
            {/* Social links */}
            <div className="flex gap-3">
              <a href="#" className="p-2 rounded-lg transition-colors" style={{ backgroundColor: 'var(--bg-card)' }}>
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" style={{ color: 'var(--text-secondary)' }}>
                  <path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z" />
                </svg>
              </a>
              <a href="#" className="p-2 rounded-lg transition-colors" style={{ backgroundColor: 'var(--bg-card)' }}>
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" style={{ color: 'var(--text-secondary)' }}>
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.052.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98C8.333 23.986 8.741 24 12 24c3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" />
                </svg>
              </a>
              <a href="#" className="p-2 rounded-lg transition-colors" style={{ backgroundColor: 'var(--bg-card)' }}>
                <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24" style={{ color: 'var(--text-secondary)' }}>
                  <path d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.479.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z" />
                </svg>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-sm font-semibold mb-4 uppercase tracking-wider" style={{ color: 'var(--text-primary)' }}>
              Liens rapides
            </h3>
            <ul className="space-y-2">
              <li>
                <Link href="/" className="text-sm transition-colors hover:text-cyan" style={{ color: 'var(--text-secondary)' }}>
                  Accueil
                </Link>
              </li>
              <li>
                <Link href="/cours" className="text-sm transition-colors hover:text-cyan" style={{ color: 'var(--text-secondary)' }}>
                  Nos cours
                </Link>
              </li>
              <li>
                <Link href="/packs" className="text-sm transition-colors hover:text-cyan" style={{ color: 'var(--text-secondary)' }}>
                  Tarifs
                </Link>
              </li>
              <li>
                <Link href="/a-propos" className="text-sm transition-colors hover:text-cyan" style={{ color: 'var(--text-secondary)' }}>
                  À propos
                </Link>
              </li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="text-sm font-semibold mb-4 uppercase tracking-wider" style={{ color: 'var(--text-primary)' }}>
              Légal
            </h3>
            <ul className="space-y-2">
              <li>
                <Link href="/conditions" className="text-sm transition-colors hover:text-cyan" style={{ color: 'var(--text-secondary)' }}>
                  Conditions d&apos;utilisation
                </Link>
              </li>
              <li>
                <Link href="/confidentialite" className="text-sm transition-colors hover:text-cyan" style={{ color: 'var(--text-secondary)' }}>
                  Confidentialité
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-sm font-semibold mb-4 uppercase tracking-wider" style={{ color: 'var(--text-primary)' }}>
              Contact
            </h3>
            <ul className="space-y-2">
              <li className="flex items-center gap-2 text-sm" style={{ color: 'var(--text-secondary)' }}>
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
                contact@drhouseacademy.com
              </li>
              <li className="flex items-center gap-2 text-sm" style={{ color: 'var(--text-secondary)' }}>
                <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                </svg>
                Alger, Algérie
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom */}
        <div className="mt-8 pt-8 border-t" style={{ borderColor: 'var(--border-color)' }}>
          <p className="text-center text-sm" style={{ color: 'var(--text-muted)' }}>
            &copy; {new Date().getFullYear()} Dr House Academy. Tous droits réservés.
          </p>
        </div>
      </div>
    </footer>
  );
}
